1:"$Sreact.fragment"
2:I[4762,[],""]
3:I[4696,[],""]
4:I[8835,[],"OutletBoundary"]
6:I[5842,[],"AsyncMetadataOutlet"]
8:I[8835,[],"ViewportBoundary"]
a:I[8835,[],"MetadataBoundary"]
b:"$Sreact.suspense"
d:I[3490,[],""]
0:{"P":null,"b":"Br04L2M36fqsD_r1PTBbg","p":"","c":["","_not-found"],"i":false,"f":[[["",{"children":["/_not-found",{"children":["__PAGE__",{}]}]},"$undefined","$undefined",true],["",["$","$1","c",{"children":[null,["$","html",null,{"lang":"es","children":["$","body",null,{"style":{"margin":0,"fontFamily":"system-ui, -apple-system, sans-serif","color":"#111"},"children":["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","main",null,{"style":{"maxWidth":640,"margin":"0 auto","padding":"48px 24px"},"children":[["$","h1",null,{"style":{"fontSize":28},"children":"404 — Página no encontrada"}],["$","p",null,{"style":{"color":"#555"},"children":"La ruta solicitada no existe en la API de TicketScan."}],["$","a",null,{"href":"/","children":"← Volver al inicio"}]]}],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}]]}],{"children":["/_not-found",["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],{"children":["__PAGE__",["$","$1","c",{"children":[["$","main",null,{"style":{"maxWidth":640,"margin":"0 auto","padding":"48px 24px"},"children":[["$","h1",null,{"style":{"fontSize":28},"children":"404 — Página no encontrada"}],["$","p",null,{"style":{"color":"#555"},"children":"La ruta solicitada no existe en la API de TicketScan."}],["$","a",null,{"href":"/","children":"← Volver al inicio"}]]}],null,["$","$L4",null,{"children":["$L5",["$","$L6",null,{"promise":"$@7"}]]}]]}],{},null,false]},null,false]},null,false],["$","$1","h",{"children":[["$","meta",null,{"name":"robots","content":"noindex"}],[["$","$L8",null,{"children":"$L9"}],null],["$","$La",null,{"children":["$","div",null,{"hidden":true,"children":["$","$b",null,{"fallback":null,"children":"$Lc"}]}]}]]}],false]],"m":"$undefined","G":["$d",[]],"s":false,"S":true}
9:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
5:null
7:{"metadata":[["$","title","0",{"children":"TicketScan API"}],["$","meta","1",{"name":"description","content":"API de TicketScan — tickets, análisis y administración."}]],"error":null,"digest":"$undefined"}
c:"$7:metadata"
